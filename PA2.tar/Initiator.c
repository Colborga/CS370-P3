#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <pthread.h>


int main(int argc, const char* argv[]){
	//Fork for Mean	
	pid_t meanPid = fork();
	int status;
	int meanEs;

	if(meanPid == 0)
	{
		//printf("here\n");		
		execlp("Mean","Mean", argv[1] , NULL);
	}
	if(meanPid > 0)
	{
		printf("Initiator: Forked process ID %d.\n", meanPid);
		printf("Initiator: waiting for process [%d].\n", meanPid);
		waitpid(meanPid, &status, 0 );
		meanEs = WEXITSTATUS(status);
		if(meanEs == 255){
			meanEs = -1;
		}
		printf("Initiator: child process %d returned with %d.\n", meanPid, meanEs);
	}

	//Fork For Median
	pid_t medianPid = fork();
	int medianEs;

	if(medianPid == 0)
	{
		//printf("here\n");		
		execlp("Median","Median",argv[1], NULL);
	}
	if(medianPid > 0)
	{
		printf("Initiator: Forked process ID %d.\n", medianPid);
		printf("Initiator: waiting for process [%d].\n", medianPid);
		waitpid(medianPid, &status, 0 );
		medianEs = WEXITSTATUS(status);
		if(medianEs == 255){
			medianEs = -1;
		}
		printf("Initiator: child process %d returned with %d.\n", medianPid, medianEs);
	}

	//Fork For Mode
	pid_t modePid = fork();
	int modeEs;

	if(modePid == 0)
	{
		//printf("here\n");		
		execlp("Mode","Mode", argv[1], NULL);
	}
	if(modePid > 0)
	{
		printf("Initiator: Forked process ID %d.\n", modePid);
		printf("Initiator: waiting for process [%d].\n", modePid);
		waitpid(modePid, &status, 0 );
		modeEs = WEXITSTATUS(status);
		if(modeEs == 255){
		modeEs = -1;
		}
		printf("Initiator: child process %d returned with %d.\n", modePid, modeEs);
	}	

	if(meanEs == 255){
		meanEs = -1;
	}
	if(medianEs == 255){
		medianEs = -1;
	}
	if(modeEs == 255){
		modeEs = -1;
	}




	//mean print
	if(meanEs < 0)
	{
		printf("The mean is negative\n");	
	}
	else if(meanEs == 0)
	{
		printf("The mean is zero\n");	
	}
	else if(meanEs > 0)
	{
		printf("The mean is positive\n");	
	}

	//median print
	if(medianEs < 0)
	{
		printf("The median is negative\n");	
	}
	else if(medianEs == 0)
	{
		printf("The median is zero\n");	
	}
	else if(medianEs > 0)
	{
		printf("The median is positive\n");	
	}

	//mode print
	if(modeEs < 0)
	{
		printf("The mode is negative\n");	
	}
	else if(modeEs == 0)
	{
		printf("The mode is zero\n");	
	}
	else if(modeEs > 0)
	{
		printf("The mode is positive\n");	
	}



	return 0;
}
