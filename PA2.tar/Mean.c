#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

float mean;

int calcMean(int passed[] , int size){
	//int hold[] = {1,2,3,4,5,6,7,8,9};		
	float sum;	
	
	for(int i = 0; i <= size; i ++){
		sum += passed[i];
	}
	
	mean = (sum)/(size); 	
	//printf("sum:%f\nmean:%f\nsize:%d\n", sum, mean, size);
	if(mean > 0){
		return 1;
	}	
	else if(mean == 0){
		return 0;
	}
	else if(mean < 0){
		return -1;
	}
	else{
		printf("%s\n", "Mean was not positive, negative ro zero");
		return -10;
	}

}

int main(int argc, const char* argv[]){
	pid_t parentPid = getpid();
	printf("Mean Process [%d]: Starting.\n", parentPid);	

	int A[10];
	FILE *fp = fopen(argv[1], "r");
	int number;	

	int i = 0;	
	fscanf(fp, "%d", &number);
	while(!feof(fp))
	{
		A[i] = number;
		fscanf(fp, "%d", &number);
		//printf("A[i]: %d\n", A[i]);
		i++;
	}	
	
	int n = sizeof(A) / sizeof(A[0]);
	int result = calcMean(A,n);

	printf("Mean: Process [%d]:  Mean is %f.\n", parentPid, mean);	
	printf("Mean: Process [%d]: Stopping.\n", parentPid);	


	//printf("%f\n", result);
	if(result == 255){
		result = -1;
	}

	return result;
;
}
